#include <iostream>

using namespace std;

void ordenarDeMenorAMayor(int *, int);
void mostrarVector(int *v, int tam=8);
void mostrarVector(float *v, int tam);
void funcion(int **var){}
void intercambiarValores(int a, int b=3, int c=4){
    int aux;
    aux = a;
    a = b;
    b = c;
    c = aux;
    cout<<a<<" - "<<b<<" - "<<c<<endl;
}

int main()
{
    int num1 = 1;
    int num2 = 2;
    int num3 = 3;
    cout<<num1<<" - "<<num2<<" - "<<num3<<endl;
    intercambiarValores(num1, num2, num3);
    //cout<<num1<<" - "<<num2<<" - "<<num3<<endl;
    int vec[8]={2,6,1,8,3,5,3,7};
    ordenarDeMenorAMayor(vec, 8);
    mostrarVector(vec);
    return 0;
}

void ordenarDeMenorAMayor(int v[], int tam){
    int aux;
    for(int i=0; i<tam-1; i++){
        for(int j=i+1; j<tam; j++){
            if(v[j]<v[i]){
                aux=v[j];
                v[j]=v[i];
                v[i]=aux;
            }
        }
    }
}

void mostrarVector(int v[], int tam){
    cout<<"MUESTRO VECTORES DE ENTEROS!"<<endl;
    for(int i=0; i<tam; i++){
        cout<<v[i]<<endl;
    }
}

void mostrarVector(float v[], int tam){
    cout<<"MUESTRO VECTORES DE FLOAT!"<<endl;
    for(int i=0; i<8; i++){
        cout<<v[i]<<endl;
    }
}
