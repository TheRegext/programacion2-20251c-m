#include <iostream>

using namespace std;

void cargarMatriz(int m[][5], int filas, int col){
    for(int i=0; i<filas; i++){
        for(int j=0; j<col; j++){
            m[i][j]=1+i*col+j;
        }
    }
}

void mostrarMatriz(int m[][5], int filas, int col){
    for(int i=0; i<filas; i++){
        for(int j=0; j<col; j++){
            cout<<m[i][j]<<" - ";
        }
        cout<<endl;
    }
}

/**
lunes
martes
miercoles
jueves
viernes
sabado
domingo
*/

/**
HACER UN PROGRAMA QUE ME PIDA EL INGRESO DEL DIA, MES
Y MONTO TOTAL FACTURADO DE LOS DIAS DEL A�O 2024
LA CARGA DE DATOS SE CORTA CON UN DIA IGUAL A CERO

HACER UNA FUNCION QUE BUSQUE E INFORME EL MES CON MAYOR FACTURACION

BONUS: MOSTRAR EN LUGAR DEL NUMERO DE MES, EL NOMBRE DEL MES (USANDO UNA
MATRIZ DE CHAR)
*/

void cargarFacturacion(float m[][31]){
    int dia, mes;
    float facturado;
    cin>>dia;
    while(dia != 0){
        cin>>mes;
        cin>>facturado;
        m[mes-1][dia-1]+=facturado;
        cin>>dia;
    }
}

void mostrarFacturacion(float m[][31], int filas, int col){
    for(int i=0; i<filas; i++){
        for(int j=0; j<col; j++){
            if(m[i][j]!=0){
                cout<<"EL DIA "<<j+1<<" DEL MES "<<i+1<<" SE FACTURO: "<<m[i][j]<<endl;
            }
        }
    }
}

int main(){
    float matDias2024[12][31]={};
    cargarFacturacion(matDias2024);
    mostrarFacturacion(matDias2024, 12, 31);
    return 0;
}

/**
int main()
{
    char dias[7][9];
    for(int i=6; i>=0; i--){
        cin>>dias[i];
    }
    for(int i=0; i<7; i++){
        cout<<dias[i]<<endl;
    }
    return 0;
    int mat[3][5];
    cargarMatriz(mat, 3, 5);
    mostrarMatriz(mat, 3, 5);
    return 0;
}
*/
