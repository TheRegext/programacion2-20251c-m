#include <iostream>

using namespace std;

/**
HACER UNA FUNCION PARA ORDENAR DE MENOR A MAYOR
UN VECTOR DE ENTEROS QUE SE RECIBE COMO PARAMETRO
Y OTRA PARA MOSTRARLO*/

void ordenarDeMenorAMayor(int v[], int tam){
    int aux;
    for(int i=0; i<tam-1; i++){
        for(int j=i+1; j<tam; j++){
            if(v[j]<v[i]){
                aux=v[j];
                v[j]=v[i];
                v[i]=aux;
            }
        }
    }
}

void mostrarVector(int v[], int tam){
    for(int i=0; i<tam; i++){
        cout<<v[i]<<endl;
    }
}

void cambiarValor(int *val){
    *val=*val*2;
}

int main()
{
    int vec[10]={4, 1, 8, 3, 6, -2, 5, 21, 33, 7};
    int valor = 11;
    cout<<*(vec+0)<<endl;
    cout<<&vec[0]+1<<endl;
    cout<<&vec[1]<<endl;
    return 0;
    int &referencia=valor;
    cambiarValor(&valor);
    cout<<referencia<<endl;
    return 0;
    const int var=10;
    ordenarDeMenorAMayor(vec, var);
    mostrarVector(vec, var);
    return 0;
    char palabra[11];
    cin>>palabra;
    cout<<palabra<<endl;
    cout<<(int)palabra[3]<<endl;
    palabra[3] = 64;
    for(int i=0; i<11; i++){
        if(palabra[i]=='\0') break;
        cout<<palabra[i];
    }
    return 0;
}
