#include <iostream>

using namespace std;

/**
HACER UN PROGRAMA CON UN VECTOR DINAMICO QUE VAYA CRECIENDO A MEDIDA
QUE SE INGRESAN VALORES
LA CARGA SE CORTA CON UN VALOR IGUAL A CERO
*/


/**
HACER UN PROGRAMA CON UNA FUNCION QUE RECIBA EL TAMA�O DEL VECTOR
Y CARGUE EN CADA POSICION LOS NUMEROS EN ORDEN DESCENDIENTE,
QUEDANDO EL 1 EN LA ULTIMA POSICION

OPCIONAL: HACER LA CARGA Y LA MUESTRA EN DOS FUNCIONES SEPARADAS
*/

void mostrarVector(int *vec, int tam){
    for(int i=0; i<tam; i++){
        cout<<vec[i]<<endl;
    }
}

int *crearVector(int tam){
    int *vec;
    if(tam <= 0) return nullptr;
    vec = new int[tam];
    if(vec == nullptr) return nullptr;
    for(int i=0; i<tam; i++){
        vec[i] = tam - i;
    }
    return vec;
}

int main(){
    int tam = 10;
    int *vec = crearVector(tam);
    if(vec == nullptr) return -1;
    mostrarVector(vec, tam);
    delete[] vec;
    return 0;
}

int mainViejo()
{
    int *vec, *aux;
    int tam=0;
    int valor;
    cout<<"INGRESE EL VALOR: ";
    cin>>valor;
    while(valor != 0){
        tam++;
        if(tam>1){
            aux = vec;
        }
        vec = new int[tam];
        if(vec == nullptr) return -1;
        if(tam>1){
            for(int i=0; i<tam-1; i++){
            vec[i] = aux[i];
            }
            delete[] aux;
        }
        vec[tam-1] = valor;
        cout<<"INGRESE EL VALOR: ";
        cin>>valor;
    }
    for(int i=0; i<tam; i++){
        cout<<vec[i]<<endl;
    }
    delete[] vec;
    return 0;
}
