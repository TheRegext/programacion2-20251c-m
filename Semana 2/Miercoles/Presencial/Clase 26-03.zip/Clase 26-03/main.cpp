#include <iostream>
#include <cstring>

using namespace std;

void cargarCadena(char *palabra, int tamano){
    int i=0;
    fflush(stdin);
    for (i=0; i<tamano; i++){
        palabra[i]=cin.get();
        if (palabra[i]=='\n'){
            break;
        }
    }
    palabra[i]='\0';
    fflush(stdin);
}

int main()
{
    char palabra[20];
    char palabra2[20];
    cout<<"INGRESE EL TEXTO: ";
    cargarCadena(palabra2, 19);
    strcpy(palabra, palabra2);
    cout<<"STRCMP ME DEVUELVE: "<<strcmp("papa", palabra)<<endl;
    return 0;
    if(strcmp(palabra, "Hola mundo!") == 0){
        cout<<"SON IGUALES"<<endl;
    }else{
        cout<<"SON DIFERENTES"<<endl;
    }
    return 0;
}
