#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

///prototipos o declaraci�n de funciones
//void cargarMaterias();
void cargarAccesos(float *v, int mat[][31]);
void materiasSinAccesos(float *v, int cant);
void materiaMasAccesos(float *v, int cant);
void accesosMarzo(int mat[][31], int materias, int dias);
int buscarPosMaximo(float *v, int cant);
///desarrollo o implementaci�n de funciones
//void cargarMaterias();
void cargarAccesos(float *v, int mat[][31]){
    int legajo, dia, mes,numeroMateria;
    float horas;
    cout<<"INGRESAR LEGAJO ";
    cin>>legajo;
    while(legajo!=0){
        cout<<"INGRESAR DIA ";
        cin>>dia;
        cout<<"INGRESAR MES ";
        cin>>mes;
        cout<<"INGRESAR NUMERO DE MATERIA ";
        cin>>numeroMateria;
        cout<<"INGRESAR HORAS ";
        cin>>horas;
        v[numeroMateria-1]+=horas;///para el punto a y b
        if(mes==3){
            mat[numeroMateria-1][dia-1]++;
        }
        cout<<"INGRESAR LEGAJO ";
        cin>>legajo;
    }

}

void materiasSinAccesos(float *v, int cant){
}

void materiaMasAccesos(float *v, int cant){
    int posMaximo=buscarPosMaximo(v,cant);
    cout<<"LA MATERIA CON MAS HORAS DE ACCESO ES "<<posMaximo+1<<endl;
}

void accesosMarzo(int mat[][31], int materias, int dias){
    int i, j;
    for(i=0;i<materias;i++){
        cout<<"MATERIA "<<i+1<<endl;
        for(j=0;j<dias;j++){
            if(mat[i][j]!=0) {
                    cout<<"DIA "<<j+1<<" ACCESOS "<<mat[i][j]<<endl;
            }
        }
    }

}

int buscarPosMaximo(float *v, int cant) {
    int i, posMax=0;
    for(i=1;i<cant;i++){
        if(v[i]>v[posMax]){
            posMax=i;
        }
    }
    return posMax;
}
#endif // FUNCIONES_H_INCLUDED
