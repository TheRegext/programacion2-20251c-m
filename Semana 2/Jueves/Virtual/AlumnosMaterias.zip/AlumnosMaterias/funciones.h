#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

///prototipos o declaraci�n de funciones
void cargarMaterias(char nombresMaterias[][25], int *cantAlumnos, int *cantDocentes, int cant);
void mostrarMaterias(char nombresMaterias[][25], int *cantAlumnos, int *cantDocentes, int cant);
void cargarAccesos(float *v, int mat[][31]);
void materiasSinAccesos(float *v, int cant);
void materiaMasAccesos(float *v, int cant);
void accesosMarzo(int mat[][31], int materias, int dias);
int buscarPosMaximo(float *v, int cant);
///desarrollo o implementaci�n de funciones
//void cargarMaterias();
///void cargarAccesos(float *v, int mat[][31], int mesAEvaluar){
void cargarAccesos(float *v, int mat[][31]){
    int legajo, dia, mes,numeroMateria;
    float horas;
    cout<<"INGRESAR LEGAJO ";
    cin>>legajo;
    while(legajo!=0){
        cout<<"INGRESAR DIA ";
        cin>>dia;
        cout<<"INGRESAR MES ";
        cin>>mes;
        cout<<"INGRESAR NUMERO DE MATERIA ";
        cin>>numeroMateria;
        cout<<"INGRESAR HORAS ";
        cin>>horas;
        v[numeroMateria-1]+=horas;///para el punto a y b
        ///if(mes==mesAEvaluar){
        if(mes==3){
            mat[numeroMateria-1][dia-1]++;
        }
        cout<<"INGRESAR LEGAJO ";
        cin>>legajo;
    }

}

void materiasSinAccesos(float *v, int cant){
}

void materiaMasAccesos(float *v, int cant){
    int posMaximo=buscarPosMaximo(v,cant);
    cout<<"LA MATERIA CON MAS HORAS DE ACCESO ES "<<posMaximo+1<<endl;
}

void accesosMarzo(int mat[][31], int materias=5, int dias=31){
    int i, j;
    for(i=0;i<materias;i++){
        cout<<"MATERIA "<<i+1<<endl;
        for(j=0;j<dias;j++){
            if(mat[i][j]!=0) {
                    cout<<"DIA "<<j+1<<" ACCESOS "<<mat[i][j]<<endl;
            }
        }
    }

}

int buscarPosMaximo(float v[], int cant) {
    int i, posMax=0;
    for(i=1;i<cant;i++){
        if(v[i]>v[posMax]){ /// cuando i=1 if(v[1]>v[0])
            posMax=i;
        }
    }
    return posMax;
}


void cargarMaterias(char nombresMaterias[][25], int *cantAlumnos, int *cantDocentes, int cant){
    int i, numeroMateria;
    for(i=0;i<cant;i++){
        cout<<"NUMERO DE MATERIA ";
        cin>>numeroMateria;
        cout<<"NOMBRE DE MATERIA ";
        cin>>nombresMaterias[numeroMateria-1];
        cout<<"CANTIDAD DE ALUMNOS ";
        cin>>cantAlumnos[numeroMateria-1];
        cout<<"CANTIDAD DE PROFESORES ";
        cin>>cantDocentes[numeroMateria-1];
    }

}

void mostrarMaterias(char nombresMaterias[][25], int *cantAlumnos, int *cantDocentes, int cant){
    int i;
    for(i=0;i<cant;i++){
        cout<<"NUMERO DE MATERIA ";
        cout<<i+1<<endl;
        cout<<"NOMBRE DE MATERIA ";
        cout<<nombresMaterias[i]<<endl;
        cout<<"CANTIDAD DE ALUMNOS ";
        cout<<cantAlumnos[i]<<endl;
        cout<<"CANTIDAD DE PROFESORES ";
        cout<<cantDocentes[i]<<endl<<endl;
    }

}


#endif // FUNCIONES_H_INCLUDED
