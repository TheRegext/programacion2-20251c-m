#include <iostream>

using namespace std;

#include "funciones.h"

int main(){
    const int MATERIAS=5;
    const int DIAS=31;
    int cantidadMaterias;

    float accesosMaterias[MATERIAS];

    int accesosMes3[MATERIAS][31]={0};
    int opc;
    ///CARGAR LAS MATERIA
    char nombreMaterias[MATERIAS][25];
    int cantidadAlumnos[MATERIAS], cantidadDocentes[MATERIAS];
    ///
    while(true){
        system("cls");
        cout<<"*******MENU PRINCIPAL********"<<endl<<endl;
        cout<<" 1. Cargar materias"<<endl;
        cout<<" 6. Mostrar materias"<<endl;
        cout<<" 2. Cargar accesos"<<endl;
        cout<<" 3. Materias sin accesos"<<endl;
        cout<<" 4. Materia con mas accesos"<<endl;
        cout<<" 5. Accesos Marzo"<<endl;
        cout<<" 0. Salir"<<endl<<endl;
        cout<<"*****************************"<<endl;
        cout<<"SELECCIONAR OPCION ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1: cargarMaterias(nombreMaterias, cantidadAlumnos, cantidadDocentes, MATERIAS);
                    break;
            case 2: cargarAccesos(accesosMaterias, accesosMes3);
                    break;
            case 3: materiasSinAccesos(accesosMaterias, MATERIAS);
                    break;
            case 4: materiaMasAccesos(accesosMaterias, MATERIAS);
                    break;
            case 5: accesosMarzo(accesosMes3);
                    break;
            case 6: mostrarMaterias(nombreMaterias, cantidadAlumnos, cantidadDocentes, MATERIAS);
                    break;
            case 0: cout<<"FIN DEL PROGRAMA"<<endl;
                    return 0;
                    break;
            default:cout<<"OPCION INCORRECTA. VUELVA A INGRESAR";
                    break;


        }
        cout<<endl;
        system("pause");
    }
    cout << endl;
    return 0;
}
