#include <iostream>
#include <cstring>

using namespace std;

/**
HACER UN PROGRAMA CON UN MEN� QUE PERMITA LA CARGA DE 20 MATERIAS.
LA INFORMACION QUE COMPONE CADA MATERIA ES:
-NUMERO DE MATERIA (DE 1 A 20).
-NOMBRE DE LA MATERIA (VECTOR CHAR).
-CANTIDAD DE ALUMNOS.
-CANTIDAD DE DOCENTES.
EL MENU DEBE TENER UNA OPCION PARA CARGAR Y OTRA PARA MOSTRAR LA
INFORMACION DE LAS MATERIAS.
OPCIONAL: AGREGAR UNA OPCION QUE PIDA EL INGRESO DE UN NUMERO DE MATERIA
Y MUESTRE LOS DATOS DE ESA MATERIA.
OPCIONAL 2: AGREGAR UNA OPCION QUE PIDA EL NOMBRE DE UNA MATERIA Y
DEVUELVA EL NUMERO DE LA MISMA.
*/

void cargarCadena(char *palabra, int tamano){
    int i=0;
    fflush(stdin);
    for (i=0; i<tamano; i++){
        palabra[i]=cin.get();
        if (palabra[i]=='\n'){
            break;
        }
    }
    palabra[i]='\0';
    fflush(stdin);
}

void cargarMaterias(char mNombres[][50], int mCant[][2], int cant);
void mostrarMaterias(char mNombres[][50], int mCant[][2], int cant);

/**
2
Matematica
250
4
1
Arquitectura y Sistemas Operativos
500
2
3
Programacion I
550
10
5
Base de datos I
300
2
4
Organizacion Empresarial
350
3
*/

/**
AGREGAR UN METODO Cargar() Y OTRO Mostrar(). EL PRIMERO DEBE PEDIRLE
AL USUARIO QUE INGRESE VALORES PARA LAS PROPIEDADES, EL SEGUNDO DEBE
MOSTRAR POR PANTALLA TODA LA INFORMACION DEL REGISTRO (LAS PROPIEDADES).
*/

class Materia{
    private:
        int numero;
        char nombre[50];
        int cantidadAlumnos;
        int cantidadDocentes;
    public:
        void setNumero(int n){
            if(n > 0 && n < 21){
                numero = n;
            }else{
                numero = 0;
            }
        }
        int getNumero(){
            return numero;
        }
        void setCantidadAlumnos(int cA){
            cantidadAlumnos = cA;
        }
        int getCantidadAlumnos(){
            return cantidadAlumnos;
        }
        void setCantidadDocentes(int cD){
            cantidadDocentes = cD;
        }
        int getCantidadDocentes(){
            return cantidadDocentes;
        }
        void setNombre(const char *n){
            strcpy(nombre, n);
        }
        const char *getNombre(){
            return nombre;
        }
};

int main()
{
    Materia reg, aux;
    Materia &referencia = reg;
    reg.setNumero(10);
    reg.setNombre("Matematica");
    reg.setCantidadAlumnos(250);
    reg.setCantidadDocentes(4);
    cout<<referencia.getNumero()<<endl;
    cout<<referencia.getNombre()<<endl;
    cout<<referencia.getCantidadAlumnos()<<endl;
    cout<<referencia.getCantidadDocentes()<<endl;
//    reg.cantidadAlumnos = 250;
//    reg.cantidadDocentes = 10;
//    strcpy(reg.nombre, "Matematica");
//    cout<<"NUMERO: "<<reg.numero<<endl;
//    cout<<"NOMBRE: "<<reg.nombre<<endl;
//    cout<<"CANTIDAD ALUMNOS: "<<reg.cantidadAlumnos<<endl;
//    cout<<"CANTIDAD DOCENTES: "<<reg.cantidadDocentes<<endl;
    cout<<endl;
    return 0;
    char mNombreMateria[5][50];
    int mCantidades[5][2];
    int opc;
    while(true){
        system("cls");
        cout<<"1 - CARGAR MATERIAS"<<endl;
        cout<<"2 - MOSTRAR MATERIAS"<<endl;
        cout<<"3 - BUSCAR MATERIA POR NUMERO"<<endl;
        cout<<"4 - BUSCAR MATERIA POR NOMBRE"<<endl;
        cout<<"0 - SALIR"<<endl;
        cout<<"INGRESE UNA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                cargarMaterias(mNombreMateria, mCantidades, 5);
                break;
            case 2:
                mostrarMaterias(mNombreMateria, mCantidades, 5);
                break;
            case 3:
                break;
            case 4:
                break;
            case 0:
                return 0;
        }
        system("pause");
    }
    return 0;
}

void cargarMaterias(char mNombres[][50], int mCant[][2], int cant){
    int numeroMateria;
    for(int i=0; i<cant; i++){
        cout<<"INGRESE EL NUMERO DE MATERIA: ";
        cin>>numeroMateria;
        cout<<"INGRESE EL NOMBRE DE LA MATERIA: ";
        cargarCadena(mNombres[numeroMateria-1], 49);
        cout<<"INGRESE LA CANTIDAD DE ALUMNOS: ";
        cin>>mCant[numeroMateria-1][0];
        cout<<"INGRESE LA CANTIDAD DE DOCENTES: ";
        cin>>mCant[numeroMateria-1][1];
    }
}

void mostrarMaterias(char mNombres[][50], int mCant[][2], int cant){
    for(int i=0; i<cant; i++){
        cout<<"NUMERO DE MATERIA: "<< i+1 <<endl;
        cout<<"NOMBRE DE LA MATERIA: "<< mNombres[i] <<endl;
        cout<<"CANTIDAD DE ALUMNOS: "<< mCant[i][0] <<endl;
        cout<<"CANTIDAD DE DOCENTES: "<< mCant[i][1] <<endl<<endl;
    }
}
